function showImage(imageSrc) {
    document.getElementById('characterImage').src = imageSrc;
}
